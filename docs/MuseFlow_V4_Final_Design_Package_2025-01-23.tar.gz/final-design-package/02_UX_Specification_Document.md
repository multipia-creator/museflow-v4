# Document 2: UX Specification Document

## 초개인화 지능형 대시보드 UX 설계 명세서

**Version:** 1.0.0  
**Date:** 2025-01-22  
**Author:** Nam Hyun-woo (남현우 교수)  
**Status:** Final Design Package

---

## 📋 Table of Contents

1. [문서 목적](#1-문서-목적)
2. [핵심 UX 원칙](#2-핵심-ux-원칙)
3. [디자인 시스템](#3-디자인-시스템)
4. [화면 구조 및 레이아웃](#4-화면-구조-및-레이아웃)
5. [초개인화 대시보드 UX](#5-초개인화-대시보드-ux)
6. [6대 작업공간 UX](#6-6대-작업공간-ux)
7. [네비게이션 시스템](#7-네비게이션-시스템)
8. [인터랙션 패턴](#8-인터랙션-패턴)
9. [반응형 디자인](#9-반응형-디자인)
10. [접근성 (Accessibility)](#10-접근성-accessibility)
11. [애니메이션 및 전환 효과](#11-애니메이션-및-전환-효과)
12. [에러 핸들링 및 피드백](#12-에러-핸들링-및-피드백)

---

## 1. 문서 목적

### 1.1 문서의 목표

본 문서는 **MuseFlow V4 시스템의 사용자 경험(UX) 설계 명세**를 정의하며, 디자인팀과 개발팀이 **일관된 사용자 인터페이스**를 구현할 수 있도록 구체적인 가이드를 제공합니다.

### 1.2 대상 독자

- **UX/UI 디자이너**: 와이어프레임 및 프로토타입 제작
- **프론트엔드 개발자**: UI 컴포넌트 구현
- **백엔드 개발자**: UX에 필요한 API 엔드포인트 이해
- **QA 팀**: 사용성 테스트 기준 수립

### 1.3 UX 설계 철학

```
"복잡한 박물관 업무를 단순하고 직관적으로"

핵심 가치:
1. Simplicity (단순성) - 불필요한 요소 제거
2. Consistency (일관성) - 모든 화면에서 동일한 패턴
3. Efficiency (효율성) - 최소 클릭으로 목표 달성
4. Intelligence (지능성) - AI가 사용자 의도를 예측
5. Delight (즐거움) - 사용하는 즐거움 제공
```

---

## 2. 핵심 UX 원칙

### 2.1 Zero-UI 원칙

**Definition:**
> 사용자가 복잡한 인터페이스를 학습하지 않고, 자연어로 의도를 표현하면 AI가 알아서 처리하는 UX

**구현 예시:**

```
전통적 UX (Multi-step):
1. "전시 기획" 메뉴 클릭
2. "새 프로젝트" 버튼 클릭
3. 폼 작성 (제목, 설명, 날짜, 예산...)
4. "작품 선정" 탭 이동
5. 검색 → 필터 → 선택 (반복)
6. "저장" 버튼 클릭

Zero-UI Approach (Single-step):
1. Command Bar에 입력: "다음 달 인상파 전시 기획해줘, 예산 1억"
   → AI가 자동으로 전시 계획, 작품 선정, 예산 분배, 일정 생성
```

### 2.2 Progressive Disclosure (점진적 노출)

**Definition:**
> 사용자에게 현재 필요한 정보와 기능만 표시하고, 나머지는 필요할 때 점진적으로 노출

**적용 사례:**

```
Level 1 (초기 화면):
┌────────────────────────────────────────┐
│ 📊 대시보드                            │
│ ├─ 오늘의 할 일 (3개)                  │
│ ├─ 진행 중인 프로젝트 (2개)             │
│ └─ 최근 활동                           │
└────────────────────────────────────────┘
        ▼ 사용자가 "프로젝트" 클릭
┌────────────────────────────────────────┐
│ 📁 프로젝트: 인상파 전시                │
│ ├─ 진행률: 67%                         │
│ ├─ 다음 마일스톤: D-7                   │
│ └─ 팀원: 5명                           │
│ [상세 보기 ▼]                          │
└────────────────────────────────────────┘
        ▼ "상세 보기" 확장
┌────────────────────────────────────────┐
│ 📁 프로젝트: 인상파 전시                │
│ ├─ 워크플로우 (18개 노드)               │
│ ├─ 예산 집행 현황                       │
│ ├─ 작품 리스트 (15점)                   │
│ ├─ 일정 (Gantt Chart)                  │
│ ├─ 팀 활동 로그                         │
│ └─ 문서 및 첨부파일                     │
└────────────────────────────────────────┘
```

### 2.3 Contextual Actions (맥락 기반 액션)

**Definition:**
> 사용자가 현재 보고 있는 콘텐츠와 맥락에 맞는 액션만 제공

**예시:**

```javascript
// 사용자가 "작품 상세 페이지"를 보고 있을 때
const contextualActions = {
  primary: [
    { label: '전시에 추가', icon: 'plus', action: 'addToExhibition' },
    { label: '보존 처리 요청', icon: 'tools', action: 'requestConservation' }
  ],
  secondary: [
    { label: '유사 작품 찾기', icon: 'search', action: 'findSimilar' },
    { label: '공유', icon: 'share', action: 'share' },
    { label: '인쇄', icon: 'print', action: 'print' }
  ],
  ai: [
    { label: 'AI 설명문 생성', icon: 'magic', action: 'generateDescription' },
    { label: 'AI 큐레이션 제안', icon: 'lightbulb', action: 'suggestCuration' }
  ]
};

// 사용자가 "예산 관리 페이지"를 보고 있을 때
const contextualActions = {
  primary: [
    { label: '비용 추가', icon: 'plus', action: 'addExpense' },
    { label: '예산 조정', icon: 'edit', action: 'adjustBudget' }
  ],
  secondary: [
    { label: '리포트 생성', icon: 'file', action: 'generateReport' },
    { label: '내보내기', icon: 'download', action: 'export' }
  ],
  ai: [
    { label: 'AI 예산 최적화', icon: 'magic', action: 'optimizeBudget' },
    { label: 'AI 지출 예측', icon: 'chart', action: 'predictSpending' }
  ]
};
```

### 2.4 Immediate Feedback (즉각적 피드백)

**Definition:**
> 모든 사용자 액션에 대해 0.1초 이내에 시각적/청각적 피드백 제공

**피드백 계층:**

```
Tier 1: Micro-interactions (< 100ms)
- 버튼 호버: 배경색 변경
- 클릭: Ripple 효과
- 입력: 실시간 유효성 검사

Tier 2: Short operations (100ms - 1s)
- 폼 제출: 로딩 스피너
- 검색: 프로그레스 바
- 저장: "저장 중..." 메시지

Tier 3: Long operations (> 1s)
- AI 생성: 단계별 진행 표시
  "작품 분석 중... 30%"
  "예산 계산 중... 60%"
  "워크플로우 생성 중... 90%"
- 파일 업로드: 진행률 + 예상 시간
- 데이터 동기화: Notion 동기화 상태 표시
```

---

## 3. 디자인 시스템

### 3.1 컬러 팔레트

```css
/* Primary Colors (주요 색상) */
--primary-50: #faf5ff;    /* Lightest purple */
--primary-100: #f3e8ff;
--primary-200: #e9d5ff;
--primary-300: #d8b4fe;
--primary-400: #c084fc;
--primary-500: #a855f7;   /* Base primary color */
--primary-600: #9333ea;   /* Hover state */
--primary-700: #7e22ce;   /* Active state */
--primary-800: #6b21a8;
--primary-900: #581c87;   /* Darkest purple */

/* Neutral Colors (중립 색상) */
--neutral-50: #fafafa;    /* Background */
--neutral-100: #f4f4f5;   /* Card background */
--neutral-200: #e4e4e7;   /* Border */
--neutral-300: #d4d4d8;   /* Disabled */
--neutral-400: #a1a1aa;   /* Placeholder */
--neutral-500: #71717a;   /* Text secondary */
--neutral-600: #52525b;   /* Text primary */
--neutral-700: #3f3f46;   /* Heading */
--neutral-800: #27272a;   /* Dark mode bg */
--neutral-900: #18181b;   /* Darkest */

/* Semantic Colors (의미 색상) */
--success: #10b981;       /* Green - Success */
--warning: #f59e0b;       /* Amber - Warning */
--error: #ef4444;         /* Red - Error */
--info: #3b82f6;          /* Blue - Info */

/* Gradient (그라데이션) */
--gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
--gradient-success: linear-gradient(135deg, #10b981 0%, #059669 100%);
--gradient-hero: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
```

### 3.2 타이포그래피

```css
/* Font Families */
--font-sans: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-mono: 'Fira Code', 'Courier New', monospace;

/* Font Sizes (1.25 scale ratio) */
--text-xs: 0.75rem;       /* 12px */
--text-sm: 0.875rem;      /* 14px */
--text-base: 1rem;        /* 16px - Body text */
--text-lg: 1.125rem;      /* 18px */
--text-xl: 1.25rem;       /* 20px */
--text-2xl: 1.5rem;       /* 24px - H3 */
--text-3xl: 1.875rem;     /* 30px - H2 */
--text-4xl: 2.25rem;      /* 36px - H1 */
--text-5xl: 3rem;         /* 48px - Hero */

/* Font Weights */
--font-light: 300;
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;

/* Line Heights */
--leading-tight: 1.25;    /* Headings */
--leading-normal: 1.5;    /* Body text */
--leading-relaxed: 1.75;  /* Long-form content */

/* Letter Spacing */
--tracking-tight: -0.025em;
--tracking-normal: 0;
--tracking-wide: 0.025em;
```

### 3.3 간격 시스템 (Spacing)

```css
/* 8px base unit (8의 배수) */
--space-0: 0;
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px - Base */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */
--space-24: 6rem;     /* 96px */

/* Layout Spacing */
--space-section: var(--space-16);     /* Section padding */
--space-container: var(--space-12);   /* Container padding */
--space-card: var(--space-6);         /* Card padding */
```

### 3.4 Shadow (그림자)

```css
/* Elevation System (Material Design inspired) */
--shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
--shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
--shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);

/* Usage */
.card { box-shadow: var(--shadow-md); }
.modal { box-shadow: var(--shadow-2xl); }
.dropdown { box-shadow: var(--shadow-lg); }
```

### 3.5 Border Radius (모서리 둥글기)

```css
--radius-none: 0;
--radius-sm: 0.25rem;   /* 4px */
--radius-md: 0.5rem;    /* 8px - Default */
--radius-lg: 0.75rem;   /* 12px */
--radius-xl: 1rem;      /* 16px */
--radius-2xl: 1.5rem;   /* 24px */
--radius-full: 9999px;  /* Circle */

/* Component-specific */
--radius-button: var(--radius-md);
--radius-card: var(--radius-lg);
--radius-modal: var(--radius-xl);
```

---

## 4. 화면 구조 및 레이아웃

### 4.1 전체 레이아웃 구조

```
┌─────────────────────────────────────────────────────────────┐
│  Global Header (64px fixed)                                  │
│  ├─ Logo                                                     │
│  ├─ Predictive Command Bar (중앙)                            │
│  ├─ AI Assistant Button                                      │
│  ├─ Notifications (3)                                        │
│  └─ User Profile                                             │
└─────────────────────────────────────────────────────────────┘
┌──────┬──────────────────────────────────────────────────────┐
│      │                                                       │
│ Side │  Main Content Area                                   │
│ Nav  │  ┌─────────────────────────────────────────────┐    │
│(240px│  │ Page Header                                  │    │
│ fixed│  │ ├─ Page Title                                │    │
│      │  │ ├─ Breadcrumb                                │    │
│      │  │ └─ Primary Actions                           │    │
│      │  └─────────────────────────────────────────────┘    │
│ Home │  ┌─────────────────────────────────────────────┐    │
│ Dash │  │                                              │    │
│ Proj │  │  Content Body (scrollable)                   │    │
│ Cal  │  │  - 대시보드 위젯 (Grid layout)                │    │
│ Team │  │  - 또는 작업공간 콘텐츠                       │    │
│ Sett │  │  - 또는 캔버스 (full-screen)                 │    │
│      │  │                                              │    │
│      │  └─────────────────────────────────────────────┘    │
│      │                                                       │
└──────┴───────────────────────────────────────────────────────┘
```

### 4.2 대시보드 그리드 시스템

```
Grid System: 12-column layout
Gap: 24px (--space-6)
Container: max-width 1440px, centered

Widget Sizes:
┌────────────────────────────────────────────────────────────┐
│ 1x1 (Small)    │ 1x2 (Medium)              │ 2x2 (Large)  │
│ ├─ Quick Stats │ ├─ Charts                 │ ├─ Calendar  │
│ ├─ KPIs        │ ├─ Lists                  │ ├─ Kanban    │
│ └─ Alerts      │ └─ Progress               │ └─ Timeline  │
│                │                            │              │
│ (4 cols)       │ (4 cols x 2 rows)          │ (8 cols x 2) │
└────────────────────────────────────────────────────────────┘

예시 레이아웃 (Curator 역할):
┌────────────────────────────────────────────────────────────┐
│ [진행 중인 전시] (2x1)       │ [이번 주 할 일] (1x1)      │
├─────────────────────────────┼────────────────────────────┤
│ [작품 추천] (2x2)                         │ [예산 현황]   │
│                                           │ (1x2)         │
├───────────────────────────────────────────┤               │
│ [최근 활동 타임라인] (2x1)                │               │
└───────────────────────────────────────────┴───────────────┘
```

### 4.3 6대 작업공간 레이아웃 템플릿

**공통 구조:**

```
┌─────────────────────────────────────────────────────────────┐
│ Workspace Header                                             │
│ ├─ Workspace Icon + Name                                    │
│ ├─ View Switcher: [List] [Board] [Calendar] [Timeline]     │
│ ├─ Filter + Sort                                            │
│ └─ Actions: [+ New] [Import] [Export] [AI Assist]          │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│ Content Area (View-dependent)                                │
│                                                              │
│ [List View]          [Board View]         [Calendar View]   │
│ ├─ Data Table       ├─ Kanban Columns    ├─ Month/Week     │
│ ├─ Pagination       ├─ Drag & Drop       ├─ Events         │
│ └─ Bulk Actions     └─ Card Details      └─ Filters         │
│                                                              │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│ Right Sidebar (Optional, 320px)                              │
│ ├─ Details Panel                                            │
│ ├─ Activity Feed                                            │
│ ├─ AI Suggestions                                           │
│ └─ Related Items                                            │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. 초개인화 대시보드 UX

### 5.1 대시보드 진입 시나리오

```
Step 1: 로그인 직후
┌─────────────────────────────────────────────────────────────┐
│ "환영합니다, 김큐레이터님! 👋"                               │
│                                                              │
│ [대시보드 로딩 중...]                                        │
│ ├─ 사용자 프로필 조회                                        │
│ ├─ 행동 패턴 분석                                            │
│ ├─ 위젯 추천 생성                                            │
│ └─ 레이아웃 최적화                                           │
│                                                              │
│ Loading Animation: Skeleton screens (not spinners)          │
└─────────────────────────────────────────────────────────────┘

Step 2: 대시보드 렌더링 (< 1초)
┌─────────────────────────────────────────────────────────────┐
│ 📊 내 대시보드                              [편집 모드 🔧]   │
│                                                              │
│ ┌──────────────────────┐ ┌──────────────────────────────┐  │
│ │ 오늘의 작업 (5)       │ │ AI 추천: 이번 주 우선순위    │  │
│ │ ☐ 전시 기획서 승인   │ │ 1. 작품 상태 점검 (D-3)      │  │
│ │ ☐ 예산안 검토        │ │ 2. 도슨트 교육 준비          │  │
│ │ ☐ 팀 회의 (2pm)     │ │ 3. SNS 콘텐츠 발행           │  │
│ └──────────────────────┘ └──────────────────────────────┘  │
│ ┌─────────────────────────────────────────────────────────┐│
│ │ 진행 중인 프로젝트 (2)                                   ││
│ │ ├─ 인상파 전시 ████████░░ 67% (D-14)                   ││
│ │ └─ 교육 프로그램 ██████████ 92% (D-3)                   ││
│ └─────────────────────────────────────────────────────────┘│
│ ┌──────────────────────┐ ┌──────────────────────────────┐  │
│ │ 이번 주 관람객 예측   │ │ 예산 집행 현황               │  │
│ │ 📈 +15% vs 지난 주   │ │ 💰 85% 집행 (15% 남음)       │  │
│ └──────────────────────┘ └──────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 위젯 시스템

**위젯 카테고리:**

```typescript
interface WidgetCatalog {
  // 1. 작업 관리 (Task Management)
  taskWidgets: [
    'Today\'s Tasks',           // 오늘의 할 일
    'Weekly Overview',          // 주간 개요
    'Priority Matrix',          // 우선순위 매트릭스
    'Overdue Alerts'            // 마감 임박 알림
  ],
  
  // 2. 프로젝트 추적 (Project Tracking)
  projectWidgets: [
    'Active Projects',          // 진행 중인 프로젝트
    'Project Timeline',         // 프로젝트 타임라인
    'Milestone Tracker',        // 마일스톤 추적
    'Team Workload'             // 팀 업무량
  ],
  
  // 3. 데이터 시각화 (Data Visualization)
  analyticsWidgets: [
    'Visitor Statistics',       // 관람객 통계
    'Budget Dashboard',         // 예산 대시보드
    'Collection Insights',      // 소장품 인사이트
    'Performance Metrics'       // 성과 지표
  ],
  
  // 4. 커뮤니케이션 (Communication)
  communicationWidgets: [
    'Team Chat Preview',        // 팀 채팅 미리보기
    'Recent Notifications',     // 최근 알림
    'Upcoming Meetings',        // 다가오는 회의
    'Activity Feed'             // 활동 피드
  ],
  
  // 5. AI 추천 (AI Recommendations)
  aiWidgets: [
    'AI Suggestions',           // AI 제안
    'Smart Prioritization',     // 스마트 우선순위
    'Predictive Insights',      // 예측 인사이트
    'Automated Reports'         // 자동 리포트
  ],
  
  // 6. 빠른 접근 (Quick Access)
  quickAccessWidgets: [
    'Favorite Actions',         // 즐겨찾기 액션
    'Recent Items',             // 최근 항목
    'Bookmarks',                // 북마크
    'Search Shortcuts'          // 검색 바로가기
  ]
}
```

**위젯 구조 (공통):**

```html
<!-- Widget Card -->
<div class="widget-card" data-widget-id="today-tasks" data-size="1x1">
  <!-- Widget Header -->
  <div class="widget-header">
    <div class="widget-icon">📋</div>
    <h3 class="widget-title">오늘의 작업</h3>
    <div class="widget-actions">
      <button class="btn-icon" data-action="refresh" aria-label="새로고침">
        <i class="fas fa-sync-alt"></i>
      </button>
      <button class="btn-icon" data-action="settings" aria-label="설정">
        <i class="fas fa-cog"></i>
      </button>
      <button class="btn-icon" data-action="remove" aria-label="제거">
        <i class="fas fa-times"></i>
      </button>
    </div>
  </div>
  
  <!-- Widget Body -->
  <div class="widget-body">
    <!-- Widget-specific content -->
    <ul class="task-list">
      <li class="task-item">
        <input type="checkbox" id="task-1">
        <label for="task-1">전시 기획서 승인</label>
        <span class="task-badge badge-urgent">긴급</span>
      </li>
      <!-- More tasks... -->
    </ul>
  </div>
  
  <!-- Widget Footer (Optional) -->
  <div class="widget-footer">
    <a href="/tasks" class="link-view-all">모두 보기 →</a>
  </div>
</div>
```

### 5.3 대시보드 편집 모드

**편집 모드 진입:**

```
1. 사용자가 "편집 모드 🔧" 버튼 클릭
   ↓
2. 대시보드 전환:
   - 모든 위젯에 "드래그 핸들" 표시
   - "+ 위젯 추가" 버튼 표시
   - 레이아웃 가이드라인 (그리드) 표시
   ↓
3. 편집 가능 액션:
   - 위젯 드래그 앤 드롭 (위치 변경)
   - 위젯 크기 조절 (1x1 → 2x1 → 2x2)
   - 위젯 추가/제거
   - 위젯 설정 (데이터 소스, 필터 등)
   ↓
4. 저장 또는 취소:
   - "저장" → POST /api/dashboard/config (레이아웃 저장)
   - "취소" → 변경사항 폐기 및 원래 레이아웃 복원
```

**위젯 추가 플로우:**

```
Step 1: "+ 위젯 추가" 버튼 클릭
  ↓
Step 2: 위젯 카탈로그 모달 오픈
┌─────────────────────────────────────────────────────────────┐
│ 위젯 추가                                        [✕ 닫기]    │
├─────────────────────────────────────────────────────────────┤
│ 검색: [__________________] 🔍                                │
│                                                              │
│ 카테고리: [전체] [작업] [프로젝트] [분석] [AI] [커뮤니케이션]│
│                                                              │
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐         │
│ │ 📋 오늘의 작업│ │ 📊 관람객 통계│ │ 🤖 AI 제안    │         │
│ │ 5개 작업 대기│ │ 주간 트렌드   │ │ 맞춤형 추천   │         │
│ │ [+ 추가]     │ │ [+ 추가]     │ │ [+ 추가]     │         │
│ └──────────────┘ └──────────────┘ └──────────────┘         │
│ (더 많은 위젯...)                                            │
└─────────────────────────────────────────────────────────────┘
  ↓
Step 3: 위젯 선택 → "추가" 클릭
  ↓
Step 4: 위젯이 대시보드에 추가됨 (기본 위치: 첫 번째 빈 공간)
  ↓
Step 5: 사용자가 원하는 위치로 드래그하여 배치
```

### 5.4 행동 학습 기반 개인화

**학습 데이터 수집:**

```javascript
// Frontend: 사용자 액션 추적
function trackUserBehavior(actionType, actionTarget, context) {
  const behaviorLog = {
    user_id: currentUser.id,
    action_type: actionType,    // 'view', 'click', 'search', 'create', 'edit'
    action_target: actionTarget, // 'exhibition-widget', 'search-bar', 'project-card'
    context: JSON.stringify(context),
    timestamp: new Date().toISOString()
  };
  
  // Send to backend
  fetch('/api/behavior-log', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(behaviorLog)
  });
}

// 예시: 사용자가 "전시 기획" 위젯을 자주 클릭
// → AI가 "전시 기획" 위젯을 대시보드 상단으로 자동 이동 제안
```

**개인화 알고리즘 (Backend):**

```typescript
// Personalization Service
interface PersonalizationEngine {
  // 1. 빈도 분석 (Frequency Analysis)
  analyzeFrequency: (userId: string, days: number = 7) => {
    // 지난 7일간 가장 많이 사용한 위젯/기능 TOP 5
    topWidgets: string[];
    topActions: string[];
  };
  
  // 2. 시간대 패턴 분석 (Temporal Pattern)
  analyzeTimePatterns: (userId: string) => {
    // 오전/오후/저녁 시간대별 주로 하는 작업
    morningActions: string[];     // 09:00-12:00
    afternoonActions: string[];   // 13:00-18:00
    eveningActions: string[];     // 18:00-21:00
  };
  
  // 3. 협업 필터링 (Collaborative Filtering)
  findSimilarUsers: (userId: string) => {
    // 같은 역할(role)의 다른 사용자들이 사용하는 위젯 추천
    similarUsers: User[];
    recommendedWidgets: string[];
  };
  
  // 4. 컨텍스트 기반 추천 (Context-Based Recommendation)
  recommendByContext: (userId: string, currentContext: string) => {
    // 현재 작업 맥락에 맞는 위젯/액션 추천
    // 예: 전시 기획 중 → "작품 추천", "예산 계산기" 위젯 제안
    recommendations: Recommendation[];
  };
}
```

---

## 6. 6대 작업공간 UX

### 6.1 전시 기획 (Exhibition Planning) 작업공간

**페이지 구조:**

```
┌─────────────────────────────────────────────────────────────┐
│ 🎨 전시 기획                                [+ 새 전시 기획]  │
├─────────────────────────────────────────────────────────────┤
│ View: [List] [Board] [Timeline] [Gallery]   Filter: [전체▼] │
└─────────────────────────────────────────────────────────────┘

[List View - 전시 목록]
┌─────────────────────────────────────────────────────────────┐
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 인상파의 빛과 색                            상태: 진행중  │ │
│ │ 2025.03.15 - 2025.06.15 | 예산: ₩100,000,000          │ │
│ │ 진행률: ████████░░ 67% | 팀원: 5명 | 작품: 15점       │ │
│ │ [상세보기] [편집] [AI 분석]                             │ │
│ └─────────────────────────────────────────────────────────┘ │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 한국 현대미술의 오늘                       상태: 계획 중 │ │
│ │ 2025.07.01 - 2025.09.30 | 예산: ₩150,000,000          │ │
│ │ 진행률: ███░░░░░░░ 25% | 팀원: 3명 | 작품: 8점        │ │
│ │ [상세보기] [편집] [AI 분석]                             │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘

[Board View - 칸반 보드]
┌───────────────┬───────────────┬───────────────┬─────────────┐
│ 📝 계획 중 (3)│ 🚀 진행 중 (2)│ ✅ 완료 (5)   │ 📦 보관 (10)│
├───────────────┼───────────────┼───────────────┼─────────────┤
│ ┌───────────┐ │ ┌───────────┐ │ ┌───────────┐ │ ┌─────────┐ │
│ │ 현대미술전 │ │ │ 인상파전  │ │ │ 조선백자전│ │ │ (past)  │ │
│ │ 67% 완료  │ │ │ 92% 완료  │ │ │ 완료됨    │ │ │         │ │
│ └───────────┘ │ └───────────┘ │ └───────────┘ │ └─────────┘ │
│ (Drag & Drop) │               │               │             │
└───────────────┴───────────────┴───────────────┴─────────────┘
```

**전시 상세 페이지:**

```
┌─────────────────────────────────────────────────────────────┐
│ ← 목록으로    인상파의 빛과 색                    [편집] [✕]│
├─────────────────────────────────────────────────────────────┤
│ Tabs: [개요] [작품] [일정] [예산] [팀] [문서] [AI 인사이트] │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│ [개요 Tab]                                                   │
│ ┌──────────────────────────────────────────────────────────┐│
│ │ 기본 정보                                                 ││
│ │ ├─ 전시명: 인상파의 빛과 색                              ││
│ │ ├─ 기간: 2025.03.15 - 2025.06.15 (92일)                 ││
│ │ ├─ 장소: 1층 전시실 A, B                                 ││
│ │ ├─ 큐레이터: 김큐레이터, 이보존가                        ││
│ │ └─ 상태: 진행 중 (67% 완료)                              ││
│ └──────────────────────────────────────────────────────────┘│
│ ┌──────────────────────────────────────────────────────────┐│
│ │ AI 생성 개요                                              ││
│ │ 이 전시는 19세기 프랑스 인상파 화가들의 빛과 색채에     ││
│ │ 대한 혁신적인 접근을 조명합니다. 모네, 르누아르...      ││
│ │ [전문 보기]                                               ││
│ └──────────────────────────────────────────────────────────┘│
│ ┌──────────────────────────────────────────────────────────┐│
│ │ 주요 지표                                                 ││
│ │ ├─ 예상 관람객: 50,000명 (AI 예측)                       ││
│ │ ├─ 예산 집행률: 85%                                       ││
│ │ ├─ 작품 준비: 15/15 (100%)                               ││
│ │ └─ 마케팅 준비: 12/20 (60%)                              ││
│ └──────────────────────────────────────────────────────────┘│
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 교육 프로그램 (Education) 작업공간

**프로그램 목록 (List View):**

```
┌─────────────────────────────────────────────────────────────┐
│ 📚 교육 프로그램                          [+ 새 프로그램 추가]│
├─────────────────────────────────────────────────────────────┤
│ Filter: [대상: 전체▼] [상태: 전체▼] [기간: 이번 달▼]        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ 어린이 미술 체험 교실                    대상: 초등 1-3  │  │
│ │ 매주 토요일 10:00-12:00 | 정원: 20명 | 신청: 18/20     │  │
│ │ 담당: 박교육사 | 만족도: ⭐⭐⭐⭐⭐ (4.8/5.0)          │  │
│ │ [상세보기] [참가자 관리] [자료 보기]                    │  │
│ └────────────────────────────────────────────────────────┘  │
│ ┌────────────────────────────────────────────────────────┐  │
│ │ 큐레이터와 함께하는 전시 해설             대상: 성인     │  │
│ │ 매주 수요일 14:00-15:00 | 정원: 30명 | 신청: 25/30     │  │
│ │ 담당: 김큐레이터 | 만족도: ⭐⭐⭐⭐⭐ (4.9/5.0)         │  │
│ │ [상세보기] [참가자 관리] [자료 보기]                    │  │
│ └────────────────────────────────────────────────────────┘  │
│                                                              │
│ [Calendar View로 전환]                                       │
│ 달력에서 일정별로 프로그램 확인 가능                         │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 6.3 수집 및 보존 (Collection & Conservation) 작업공간

**소장품 검색 인터페이스:**

```
┌─────────────────────────────────────────────────────────────┐
│ 🏛️ 소장품 관리                                               │
├─────────────────────────────────────────────────────────────┤
│ 검색: [____________________________] 🔍 [AI 검색] [음성 검색]│
│                                                              │
│ 고급 필터:                                                   │
│ ├─ 시대: [전체▼] [조선] [고려] [현대]                        │
│ ├─ 재료: [전체▼] [도자기] [회화] [조각] [금속]               │
│ ├─ 상태: [전체▼] [양호] [보통] [보존처리 필요]               │
│ ├─ 보관 위치: [전체▼] [1층 수장고] [2층 수장고] [전시 중]    │
│ └─ 색상: [__] [__] [__] [__] (색상 팔레트 선택)             │
│                                                              │
│ View: [Grid] [List] [Map]        정렬: [등록일▼]            │
└─────────────────────────────────────────────────────────────┘

[Grid View - 썸네일 그리드]
┌───────────┬───────────┬───────────┬───────────┬───────────┐
│ ┌───────┐ │ ┌───────┐ │ ┌───────┐ │ ┌───────┐ │ ┌───────┐ │
│ │[Image]│ │ │[Image]│ │ │[Image]│ │ │[Image]│ │ │[Image]│ │
│ └───────┘ │ └───────┘ │ └───────┘ │ └───────┘ │ └───────┘ │
│ 백자대호   │ 산수도     │ 금동미륵  │ 청자향로  │ 풍속화    │
│ 조선 18세기│ 조선 19세기│ 삼국시대  │ 고려 12세기│ 조선 17세기│
│ 상태: 양호 │ 상태: 보통 │보존처리중 │ 상태: 양호│ 상태: 보통│
└───────────┴───────────┴───────────┴───────────┴───────────┘

[작품 상세 페이지 - 우측 슬라이드 패널]
┌─────────────────────────────────────────────────────────────┐
│ [✕ 닫기]                      백자대호 (白磁大壺)            │
├─────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────┐ │
│ │                   [고해상도 이미지]                       │ │
│ │               (360도 회전 뷰 지원)                        │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                              │
│ 기본 정보:                                                   │
│ ├─ 소장번호: 2025.047                                        │
│ ├─ 시대: 조선시대 18세기                                     │
│ ├─ 재료: 백자                                                │
│ ├─ 크기: 높이 45cm, 구경 20cm                               │
│ ├─ 무게: 3.2kg                                               │
│ └─ 보관 위치: 1층 수장고 A-25                                │
│                                                              │
│ 상태 정보:                                                   │
│ ├─ 현재 상태: 양호 (95점)                                    │
│ ├─ 최근 점검: 2025-01-15                                     │
│ └─ 다음 점검: 2025-04-15                                     │
│                                                              │
│ AI 분석:                                                     │
│ ├─ 자동 태그: #조선백자 #대호 #18세기 #백자                  │
│ ├─ 유사 작품: 3점 발견                                       │
│ └─ 추천 전시: "조선 백자의 아름다움" 전시에 추천             │
│                                                              │
│ [전시에 추가] [보존처리 요청] [공유] [인쇄]                  │
└─────────────────────────────────────────────────────────────┘
```

### 6.4 출판 (Publication) 작업공간

### 6.5 연구 (Research) 작업공간

### 6.6 행정 (Administration) 작업공간

_(각 작업공간의 상세한 UX 명세는 동일한 패턴으로 작성됩니다.)_

---

## 7. 네비게이션 시스템

### 7.1 Global Header

```html
<header class="global-header">
  <!-- Logo -->
  <div class="logo">
    <img src="/logo-icon.png" alt="MuseFlow" width="32" height="32">
    <span class="logo-text">MuseFlow</span>
  </div>
  
  <!-- Predictive Command Bar -->
  <div class="command-bar">
    <button class="command-trigger" aria-label="명령 검색 (Ctrl+K)">
      <i class="fas fa-search"></i>
      <span class="command-placeholder">무엇을 도와드릴까요?</span>
      <kbd>⌘K</kbd>
    </button>
  </div>
  
  <!-- Right Actions -->
  <div class="header-actions">
    <!-- AI Assistant -->
    <button class="btn-ai-assistant" aria-label="AI 어시스턴트">
      <i class="fas fa-robot"></i>
    </button>
    
    <!-- Notifications -->
    <button class="btn-notifications" aria-label="알림" data-count="3">
      <i class="fas fa-bell"></i>
      <span class="notification-badge">3</span>
    </button>
    
    <!-- User Profile -->
    <div class="user-profile-dropdown">
      <button class="btn-user-profile" aria-label="사용자 메뉴">
        <img src="/profile.jpg" alt="김큐레이터" class="avatar">
        <span class="user-name">김큐레이터</span>
        <i class="fas fa-chevron-down"></i>
      </button>
      <!-- Dropdown Menu -->
      <div class="dropdown-menu">
        <a href="/account">내 계정</a>
        <a href="/settings">설정</a>
        <a href="/help">도움말</a>
        <hr>
        <a href="/logout">로그아웃</a>
      </div>
    </div>
  </div>
</header>
```

### 7.2 Side Navigation

```html
<nav class="side-nav">
  <ul class="nav-list">
    <!-- Primary Navigation -->
    <li class="nav-item active">
      <a href="/dashboard" class="nav-link">
        <i class="fas fa-home"></i>
        <span>대시보드</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/projects" class="nav-link">
        <i class="fas fa-folder"></i>
        <span>프로젝트</span>
        <span class="nav-badge">5</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/calendar" class="nav-link">
        <i class="fas fa-calendar"></i>
        <span>캘린더</span>
      </a>
    </li>
    
    <!-- Workspace Navigation -->
    <li class="nav-section-title">작업공간</li>
    
    <li class="nav-item">
      <a href="/workspace/exhibition" class="nav-link">
        <i class="fas fa-palette"></i>
        <span>전시 기획</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/workspace/education" class="nav-link">
        <i class="fas fa-graduation-cap"></i>
        <span>교육 프로그램</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/workspace/collection" class="nav-link">
        <i class="fas fa-archive"></i>
        <span>수집·보존</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/workspace/publication" class="nav-link">
        <i class="fas fa-book"></i>
        <span>출판</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/workspace/research" class="nav-link">
        <i class="fas fa-microscope"></i>
        <span>연구</span>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="/workspace/admin" class="nav-link">
        <i class="fas fa-cog"></i>
        <span>행정</span>
      </a>
    </li>
    
    <!-- Bottom Actions -->
    <li class="nav-item nav-bottom">
      <a href="/settings" class="nav-link">
        <i class="fas fa-gear"></i>
        <span>설정</span>
      </a>
    </li>
  </ul>
</nav>
```

### 7.3 Breadcrumb Navigation

```html
<nav class="breadcrumb" aria-label="Breadcrumb">
  <ol class="breadcrumb-list">
    <li class="breadcrumb-item">
      <a href="/dashboard">대시보드</a>
    </li>
    <li class="breadcrumb-separator">›</li>
    <li class="breadcrumb-item">
      <a href="/workspace/exhibition">전시 기획</a>
    </li>
    <li class="breadcrumb-separator">›</li>
    <li class="breadcrumb-item active" aria-current="page">
      인상파의 빛과 색
    </li>
  </ol>
</nav>
```

---

## 8. 인터랙션 패턴

### 8.1 Predictive Command Bar (예측 명령 바)

**트리거:**
- Keyboard: `Ctrl+K` (Windows) 또는 `⌘K` (Mac)
- Mouse: Global Header의 검색창 클릭

**동작:**

```
Step 1: Command Bar 모달 오픈
┌─────────────────────────────────────────────────────────────┐
│                     [ESC로 닫기]                             │
│                                                              │
│  🔍 [____________________________________]                   │
│      무엇을 도와드릴까요?                                    │
│                                                              │
│  💡 추천 액션:                                               │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ 🎨 새 전시 기획하기                           Ctrl+E    │ │
│  │ 📋 오늘의 할 일 확인                          Ctrl+T    │ │
│  │ 📊 관람객 통계 보기                           Ctrl+S    │ │
│  │ 👥 팀 회의 일정 잡기                          Ctrl+M    │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  🕐 최근 사용:                                               │
│  - 인상파 전시 프로젝트                                      │
│  - 작품 등록: 백자대호                                       │
│  - 예산 리포트 2025-01                                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘

Step 2: 사용자 입력 (자연어)
┌─────────────────────────────────────────────────────────────┐
│  🔍 [다음 달 현대미술 전시 기획해줘, 예산 1억5천_____]       │
│                                                              │
│  🔎 검색 결과:                                               │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ ✨ AI 워크플로우 생성                                   │ │
│  │    "현대미술 전시 기획" 워크플로우 자동 생성             │ │
│  │    예산: ₩150,000,000 | 기간: 2025-03-01 ~ 05-31      │ │
│  │    → Enter로 생성 시작                                   │ │
│  ├────────────────────────────────────────────────────────┤ │
│  │ 📁 유사 프로젝트                                        │ │
│  │    2024 한국 현대미술전 (완료)                          │ │
│  │    → 템플릿으로 사용                                     │ │
│  ├────────────────────────────────────────────────────────┤ │
│  │ 🎨 작품 검색                                            │ │
│  │    "현대미술" 키워드로 소장품 검색 (125개 결과)         │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘

Step 3: AI 워크플로우 생성 (선택 시)
┌─────────────────────────────────────────────────────────────┐
│  ⏳ AI가 워크플로우를 생성하고 있습니다...                    │
│                                                              │
│  Progress: ████████████████░░░░ 75%                         │
│                                                              │
│  ✓ 전시 컨셉 생성 완료                                       │
│  ✓ 작품 선정 (12점) 완료                                     │
│  ✓ 예산 배분 완료                                            │
│  ⏳ 일정 계획 생성 중...                                     │
│                                                              │
│  예상 완료 시간: 5초                                         │
└─────────────────────────────────────────────────────────────┘

Step 4: 완료 및 Canvas로 이동
→ 자동으로 Canvas 페이지로 이동, 생성된 워크플로우 표시
```

### 8.2 Drag & Drop 인터랙션

**대시보드 위젯 드래그:**

```javascript
// Drag Start
onDragStart(widget) {
  // 1. 드래그 중인 위젯 반투명 처리
  widget.style.opacity = 0.5;
  
  // 2. 드래그 프리뷰 생성 (커서 따라다니는 미니 버전)
  const preview = createDragPreview(widget);
  document.body.appendChild(preview);
  
  // 3. 그리드 가이드라인 표시 (가능한 위치 하이라이트)
  showGridGuidelines();
}

// Drag Over (다른 위젯 위로 이동 시)
onDragOver(targetWidget) {
  // 1. 스왑 위치 미리보기 (애니메이션)
  animateSwapPreview(draggedWidget, targetWidget);
  
  // 2. 스냅 효과 (그리드에 맞춰 정렬)
  snapToGrid(draggedWidget);
}

// Drop (드롭 시)
onDrop(targetPosition) {
  // 1. 위젯 위치 업데이트
  updateWidgetPosition(draggedWidget, targetPosition);
  
  // 2. 레이아웃 재계산 (다른 위젯들도 자동 정렬)
  recalculateLayout();
  
  // 3. 애니메이션으로 부드럽게 이동
  animateToPosition(draggedWidget, targetPosition);
  
  // 4. 변경사항 저장 (자동 저장)
  saveDashboardLayout();
  
  // 5. 성공 피드백 (햅틱, 사운드)
  playSuccessSound();
  widget.style.opacity = 1;
}
```

### 8.3 Context Menu (우클릭 메뉴)

```javascript
// 우클릭 이벤트
onContextMenu(event, target) {
  event.preventDefault();
  
  // 타겟에 따라 다른 컨텍스트 메뉴 표시
  if (target.classList.contains('widget-card')) {
    showWidgetContextMenu(event.clientX, event.clientY, target);
  } else if (target.classList.contains('project-card')) {
    showProjectContextMenu(event.clientX, event.clientY, target);
  }
}

function showWidgetContextMenu(x, y, widget) {
  const menu = `
    <div class="context-menu" style="left:${x}px; top:${y}px;">
      <button data-action="refresh">
        <i class="fas fa-sync-alt"></i> 새로고침
      </button>
      <button data-action="resize">
        <i class="fas fa-expand"></i> 크기 조절
      </button>
      <button data-action="duplicate">
        <i class="fas fa-copy"></i> 복제
      </button>
      <hr>
      <button data-action="remove" class="text-danger">
        <i class="fas fa-trash"></i> 제거
      </button>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', menu);
}
```

### 8.4 Toast Notifications (알림)

```javascript
// Toast 표시 함수
function showToast(message, type = 'info', duration = 3000) {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-icon">
      ${getIconForType(type)}
    </div>
    <div class="toast-content">
      <div class="toast-message">${message}</div>
    </div>
    <button class="toast-close" aria-label="닫기">
      <i class="fas fa-times"></i>
    </button>
  `;
  
  // 우측 하단에 표시
  const toastContainer = document.querySelector('.toast-container');
  toastContainer.appendChild(toast);
  
  // 애니메이션 (슬라이드 인)
  setTimeout(() => toast.classList.add('show'), 10);
  
  // 자동 제거
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// 사용 예시
showToast('워크플로우가 생성되었습니다!', 'success');
showToast('저장 중 오류가 발생했습니다.', 'error');
showToast('변경사항이 자동 저장되었습니다.', 'info', 2000);
```

---

## 9. 반응형 디자인

### 9.1 Breakpoints

```css
/* Mobile First Approach */
/* Extra Small (xs): < 640px (Mobile Portrait) */
@media (max-width: 639px) {
  .side-nav { display: none; }
  .global-header { padding: 0 1rem; }
  .dashboard-grid { grid-template-columns: 1fr; }
}

/* Small (sm): 640px - 767px (Mobile Landscape) */
@media (min-width: 640px) and (max-width: 767px) {
  .side-nav { width: 60px; } /* Collapsed */
  .dashboard-grid { grid-template-columns: repeat(2, 1fr); }
}

/* Medium (md): 768px - 1023px (Tablet) */
@media (min-width: 768px) and (max-width: 1023px) {
  .side-nav { width: 240px; }
  .dashboard-grid { grid-template-columns: repeat(3, 1fr); }
}

/* Large (lg): 1024px - 1279px (Desktop) */
@media (min-width: 1024px) and (max-width: 1279px) {
  .side-nav { width: 240px; }
  .dashboard-grid { grid-template-columns: repeat(4, 1fr); }
}

/* Extra Large (xl): >= 1280px (Large Desktop) */
@media (min-width: 1280px) {
  .side-nav { width: 240px; }
  .dashboard-grid { grid-template-columns: repeat(6, 1fr); }
}
```

### 9.2 모바일 UX 최적화

```
Mobile View (< 640px):
┌─────────────────────────────────┐
│ [☰]  MuseFlow      [🔔] [@]     │ Header (Hamburger menu)
├─────────────────────────────────┤
│ 🔍 검색...               [✕]    │ Search Bar (Fullscreen)
├─────────────────────────────────┤
│                                 │
│ ┌─────────────────────────────┐ │
│ │ 오늘의 할 일 (5)             │ │ Widget (Full width)
│ │ ☐ 전시 기획서 승인           │ │
│ │ ☐ 예산안 검토                │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ 진행 중인 프로젝트 (2)       │ │
│ │ 인상파 전시 ████░ 67%       │ │
│ └─────────────────────────────┘ │
│ ┌─────────────────────────────┐ │
│ │ AI 추천: 우선순위            │ │
│ │ 1. 작품 상태 점검 (D-3)     │ │
│ └─────────────────────────────┘ │
│                                 │
│ (스크롤 계속...)                │
│                                 │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│ [🏠] [📁] [📅] [👥] [⚙️]        │ Bottom Navigation
└─────────────────────────────────┘
```

---

## 10. 접근성 (Accessibility)

### 10.1 WCAG 2.1 AA 준수

```yaml
Color Contrast:
  - Normal Text: 4.5:1 이상
  - Large Text (18pt+): 3:1 이상
  - UI Components: 3:1 이상

Keyboard Navigation:
  - Tab 순서: 논리적 순서
  - Focus Indicator: 명확한 포커스 표시 (2px solid)
  - Skip Links: "본문으로 건너뛰기" 링크 제공

Screen Reader:
  - ARIA Labels: 모든 인터랙티브 요소
  - ARIA Roles: 적절한 역할 정의
  - ARIA Live Regions: 동적 콘텐츠 알림

Semantic HTML:
  - <header>, <nav>, <main>, <footer>
  - <article>, <section>, <aside>
  - Proper heading hierarchy (h1 → h2 → h3)
```

### 10.2 키보드 단축키

```javascript
const keyboardShortcuts = {
  global: {
    'Ctrl+K': 'Command Bar 열기',
    'Ctrl+/': '단축키 도움말 열기',
    'Ctrl+S': '저장',
    'Ctrl+Z': '실행 취소',
    'Ctrl+Shift+Z': '다시 실행',
    'Esc': '모달/팝오버 닫기'
  },
  
  navigation: {
    'Ctrl+1': '대시보드로 이동',
    'Ctrl+2': '프로젝트로 이동',
    'Ctrl+3': '캘린더로 이동',
    'Ctrl+4': '팀으로 이동',
    'Ctrl+5': '설정으로 이동'
  },
  
  dashboard: {
    'Ctrl+E': '편집 모드 토글',
    'Ctrl+W': '위젯 추가',
    'Ctrl+R': '대시보드 새로고침'
  },
  
  canvas: {
    'Space': '팬 모드 (드래그로 이동)',
    'Ctrl++': '확대',
    'Ctrl+-': '축소',
    'Ctrl+0': '100% 크기로',
    'Delete': '선택된 노드 삭제',
    'Ctrl+D': '선택된 노드 복제',
    'Ctrl+A': '전체 선택'
  }
};
```

---

## 11. 애니메이션 및 전환 효과

### 11.1 애니메이션 원칙

```css
/* Duration (지속 시간) */
--duration-instant: 100ms;   /* Micro-interactions */
--duration-fast: 200ms;      /* Hover, Focus */
--duration-normal: 300ms;    /* Transitions */
--duration-slow: 500ms;      /* Page transitions */

/* Easing (이징 함수) */
--ease-in: cubic-bezier(0.4, 0, 1, 1);           /* 가속 */
--ease-out: cubic-bezier(0, 0, 0.2, 1);          /* 감속 */
--ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);     /* 가속+감속 */
--ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55); /* 바운스 */

/* Usage */
.button {
  transition: all var(--duration-fast) var(--ease-out);
}

.modal {
  animation: slideIn var(--duration-normal) var(--ease-out);
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

### 11.2 페이지 전환

```javascript
// Page Transition (SPA)
function navigateToPage(url) {
  // 1. Fade out current page
  const currentPage = document.querySelector('.page-content');
  currentPage.classList.add('fade-out');
  
  // 2. Load new content (200ms delay)
  setTimeout(async () => {
    const newContent = await fetchPageContent(url);
    currentPage.innerHTML = newContent;
    
    // 3. Fade in new page
    currentPage.classList.remove('fade-out');
    currentPage.classList.add('fade-in');
    
    // 4. Update browser history
    history.pushState({}, '', url);
  }, 200);
}
```

---

## 12. 에러 핸들링 및 피드백

### 12.1 에러 상태 표시

```javascript
// Form Validation Error
function showFieldError(fieldElement, errorMessage) {
  fieldElement.classList.add('error');
  fieldElement.setAttribute('aria-invalid', 'true');
  
  const errorElement = document.createElement('div');
  errorElement.className = 'error-message';
  errorElement.id = `${fieldElement.id}-error`;
  errorElement.textContent = errorMessage;
  errorElement.setAttribute('role', 'alert');
  
  fieldElement.parentElement.appendChild(errorElement);
  fieldElement.setAttribute('aria-describedby', errorElement.id);
}

// Network Error
function showNetworkError(message) {
  showToast(
    '네트워크 오류가 발생했습니다. 인터넷 연결을 확인해주세요.',
    'error',
    5000
  );
}

// API Error
function handleAPIError(error) {
  if (error.status === 401) {
    // Unauthorized → Redirect to login
    window.location.href = '/login';
  } else if (error.status === 403) {
    // Forbidden → Show permission error
    showToast('이 작업을 수행할 권한이 없습니다.', 'error');
  } else if (error.status === 500) {
    // Server error → Show generic error
    showToast('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.', 'error');
  }
}
```

### 12.2 Empty States (빈 상태)

```html
<!-- 프로젝트가 없을 때 -->
<div class="empty-state">
  <div class="empty-state-icon">
    <i class="fas fa-folder-open fa-4x"></i>
  </div>
  <h3 class="empty-state-title">아직 프로젝트가 없습니다</h3>
  <p class="empty-state-description">
    새 프로젝트를 만들어 박물관 업무를 시작하세요.
  </p>
  <button class="btn btn-primary">
    <i class="fas fa-plus"></i> 첫 프로젝트 만들기
  </button>
</div>

<!-- 검색 결과가 없을 때 -->
<div class="empty-state">
  <div class="empty-state-icon">
    <i class="fas fa-search fa-4x"></i>
  </div>
  <h3 class="empty-state-title">검색 결과가 없습니다</h3>
  <p class="empty-state-description">
    다른 키워드로 검색하거나 필터를 조정해보세요.
  </p>
  <button class="btn btn-secondary" onclick="clearSearch()">
    검색 초기화
  </button>
</div>
```

---

## 부록 A: 컴포넌트 라이브러리

```css
/* Buttons */
.btn {
  padding: 0.75rem 1.5rem;
  border-radius: var(--radius-button);
  font-weight: var(--font-medium);
  transition: all var(--duration-fast) var(--ease-out);
}

.btn-primary {
  background: var(--primary-600);
  color: white;
}

.btn-primary:hover {
  background: var(--primary-700);
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

/* Cards */
.card {
  background: white;
  border-radius: var(--radius-card);
  box-shadow: var(--shadow-sm);
  padding: var(--space-card);
  transition: box-shadow var(--duration-fast) var(--ease-out);
}

.card:hover {
  box-shadow: var(--shadow-md);
}

/* Inputs */
.input {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1px solid var(--neutral-300);
  border-radius: var(--radius-md);
  font-size: var(--text-base);
  transition: border-color var(--duration-fast) var(--ease-out);
}

.input:focus {
  outline: none;
  border-color: var(--primary-500);
  box-shadow: 0 0 0 3px rgba(168, 85, 247, 0.1);
}

/* Badges */
.badge {
  display: inline-flex;
  align-items: center;
  padding: 0.25rem 0.75rem;
  border-radius: var(--radius-full);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
}

.badge-success {
  background: var(--success);
  color: white;
}

.badge-warning {
  background: var(--warning);
  color: white;
}

.badge-error {
  background: var(--error);
  color: white;
}
```

---

## 부록 B: UX 검토 체크리스트

```yaml
사용성 (Usability):
  - [ ] 3클릭 이내에 모든 주요 기능 접근 가능
  - [ ] 명확한 시각적 계층 구조
  - [ ] 일관된 UI 패턴
  - [ ] 즉각적인 피드백 (< 100ms)
  - [ ] 에러 복구 기능 (실행 취소)

접근성 (Accessibility):
  - [ ] WCAG 2.1 AA 준수
  - [ ] 키보드로 모든 기능 접근 가능
  - [ ] 스크린 리더 호환성
  - [ ] 색상 대비 4.5:1 이상
  - [ ] 대체 텍스트 제공

성능 (Performance):
  - [ ] 페이지 로드 < 1.5s
  - [ ] 애니메이션 60fps
  - [ ] 이미지 Lazy Loading
  - [ ] 번들 크기 < 500KB

모바일 (Mobile):
  - [ ] 반응형 디자인
  - [ ] 터치 타겟 44px 이상
  - [ ] 가로/세로 모드 지원
  - [ ] 스와이프 제스처
```

---

## Document Metadata

- **Version**: 1.0.0
- **Last Updated**: 2025-01-22
- **Next Review**: 2025-02-22
- **Owner**: Nam Hyun-woo (남현우 교수)
- **Reviewers**: Design Team, Frontend Team
- **Confidentiality**: Internal Use Only

---

**End of Document 2: UX Specification Document**
